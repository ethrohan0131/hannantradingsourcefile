interface User {
	fullname?: string;
	fathername?: string;
	mothername?: string;
	email?: string;
	phone?: string;
	house_no?: string;
	village?: string;
	po?: string;
	ps?: string;
	district?: string;
	password?: string;
	nid_number?: string;
	bank_account_number?: string;
	bank_account_holder_name?: string;
	bank_name?: string;
	bank_district?: string;
	bank_branch?: string;
	profile_picture?: string;
	routing_number?: string;
	signature?: string;
	clerkId?: string;
}

export default User;
