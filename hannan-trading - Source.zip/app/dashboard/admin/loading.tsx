"use client";

import { Spin } from "antd";

export default function Loading() {
	return <Spin size="large" fullscreen />;
}
