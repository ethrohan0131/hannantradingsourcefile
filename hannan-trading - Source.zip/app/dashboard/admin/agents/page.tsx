"use client";
import * as XLSX from "xlsx";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { useState, useEffect, useRef } from "react";
import toast from "react-hot-toast";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";
import { Spin } from "antd";
import { Check, CheckCheck, Trash } from "lucide-react";
import { BengaliNumber } from "to-bengali";
import { X } from "lucide-react";

interface BankInfo {
	bank_account_number: string;
	bank_account_holder_name: string;
	bank_name: string;
	bank_district: string;
	bank_branch: string;
	routing_number: string;
}

interface User {
	_id: string;
	fullname: string;
	fathername: string;
	mothername: string;
	email: string;
	phone: string;
	house_no: string;
	village: string;
	po: string;
	ps: string;
	district: string;
	bank_info: BankInfo[];
	nid_number: string;
	profile_picture: string;
	signature: string;
	clerkId: string;
	role: string[];
	admin_verified: boolean;
	amount: number;
}

export default function Events() {
	const router = useRouter();
	const [search_text, setSearchText] = useState("");
	const [page, setPage] = useState(1);
	const [agents, setAgents] = useState<User[]>([]);
	const [loading, setLoading] = useState(false);
	const [totalPages, setTotalPages] = useState(0);
	const [search_trigger, setSearchTrigger] = useState(false);
	const [days, setDays] = useState(365);

	const fetchEvents = async () => {
		setLoading(true);
		const response = await fetch("/api/admin/funds/get-funds", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({
				page,
				search_text,
			}),
		});
		const data = await response.json();
		if (response.ok) {
			setAgents(data.data);
			setTotalPages(data.totalPages);
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	};

	useEffect(() => {
		fetchEvents();
	}, [page, search_trigger]);

	async function handleSearch() {
		setPage(1);
		setSearchTrigger(!search_trigger);
	}

	return (
		<div className="py-[32px] bg-white h-full overflow-y-auto px-[24px]  w-full flex flex-col gap-[24px]">
			<TopTitle router={router} />

			<div className="border rounded-lg w-full pb-4 flex flex-col gap-[24px]">
				<div>
					<SearchBar
						search_text={search_text}
						setSearchText={setSearchText}
						handleSearch={handleSearch}
						agents={agents}
						days={days}
						setDays={setDays}
					/>
					<SortingBar />
					<div className="w-full">
						{loading && (
							<div className="w-full flex justify-center items-center">
								<Spin size="large" />
							</div>
						)}
						{!loading &&
							agents &&
							agents.map((agent, index) => (
								<RowCard
									key={index}
									agent={agent}
									index={index}
									agents={agents}
									setAgents={setAgents}
								/>
							))}
					</div>
				</div>

				{!loading && (
					<Pagination
						page={page}
						setPage={setPage}
						totalPages={totalPages}
					/>
				)}
			</div>
		</div>
	);
}

function Pagination({
	page,
	setPage,
	totalPages,
}: {
	page: number;
	setPage: (page: number) => void;
	totalPages: number;
}) {
	const renderPageNumbers = () => {
		const pageNumbers = [];
		const startPage = Math.max(2, page - 1);
		const endPage = Math.min(totalPages - 1, page + 1);

		if (page > 3) {
			pageNumbers.push(1, "...");
		} else {
			pageNumbers.push(1);
		}

		for (let i = startPage; i <= endPage; i++) {
			pageNumbers.push(i);
		}

		if (page < totalPages - 2) {
			pageNumbers.push("...", totalPages);
		} else if (totalPages > 1) {
			pageNumbers.push(totalPages);
		}

		return pageNumbers.map((num, idx) =>
			typeof num === "string" ? (
				<span key={idx} className="text-[#414651] px-2">
					{num}
				</span>
			) : (
				<button
					key={idx}
					onClick={() => setPage(num)}
					className={`px-[16px] py-[8px]  font-semibold rounded-md ${
						num === page
							? "bg-[#FAFAFA] text-[#252B37]"
							: "text-[#535862]"
					}`}
				>
					{num}
				</button>
			)
		);
	};

	return (
		<div className="w-full px-4 flex justify-between items-center gap-4">
			<button
				onClick={() => {
					if (page > 1) setPage(page - 1);
				}}
				className={`text-[#414651] cursor-pointer disabled:cursor-default hover:bg-slate-50 disabled:hover:bg-white px-3 py-2 border disabled:border-[#E9EAEB] border-[#D5D7DA] flex gap-2 items-center disabled:text-[#A4A7AE] h-fit font-semibold rounded-lg`}
				disabled={page === 1}
			>
				<Image
					src="/assets/Icons/arrow-left.svg"
					alt="left"
					width={20}
					height={20}
					className="disabled:opacity-10"
				/>
				<span className="hidden lg:flex">পূর্ববর্তী</span>
			</button>
			<div className="text-[#414651] flex items-center gap-1">
				{renderPageNumbers()}
			</div>
			<button
				onClick={() => {
					if (page < totalPages) setPage(page + 1);
				}}
				className={`text-[#414651] cursor-pointer disabled:cursor-default hover:bg-slate-50 disabled:hover:bg-white px-3 py-2 border disabled:border-[#E9EAEB] border-[#D5D7DA] flex gap-2 items-center disabled:text-[#A4A7AE] h-fit font-semibold rounded-lg`}
				disabled={page === totalPages}
			>
				<span className="hidden lg:flex">পরবর্তী</span>
				<Image
					src="/assets/Icons/arrow-right.svg"
					alt="right"
					width={20}
					height={20}
					className="disabled:opacity-10"
				/>
			</button>
		</div>
	);
}

const Modal = ({
	agent,
	is_visible,
	onClose,
}: {
	agent: User;
	is_visible: boolean;
	onClose: () => void;
}) => {
	const modalRef = useRef<HTMLDivElement>(null);

	const handleOutsideClick = (e: React.MouseEvent) => {
		if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
			onClose();
		}
	};

	if (!is_visible) return null;

	const {
		fullname,
		fathername,
		mothername,
		email,
		phone,
		house_no,
		village,
		po,
		ps,
		district,
		bank_info,
		nid_number,
		profile_picture,
		signature,
	} = agent;

	const {
		bank_account_number,
		bank_account_holder_name,
		bank_name,
		bank_district,
		bank_branch,
		routing_number,
	} = bank_info[0];

	return (
		<div
			onClick={handleOutsideClick}
			className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-md"
		>
			<div
				ref={modalRef}
				className="relative mx-6 w-full max-w-3xl p-4 overflow-y-auto bg-white rounded-lg shadow-lg max-h-[90vh] md:w-3/4 lg:w-2/3"
			>
				<button
					className="absolute top-3  right-3 text-gray-500 hover:text-gray-800"
					onClick={onClose}
					title="বন্ধ করুন"
				>
					<X className="w-6 h-6" />
				</button>
				<h2 className="mb-4 text-xl font-semibold text-center text-gray-800">
					প্রোফাইল তথ্য
				</h2>
				<div className="grid gap-4 md:grid-cols-2">
					<div className="flex flex-col items-center">
						<label className="mb-2 text-sm font-medium text-gray-600">
							প্রোফাইল ছবি
						</label>
						<div className="max-w-[300px] min-w-[300px] w-full h-full min-h-[300px] max-h-[300px]">
							<img
								src={profile_picture}
								alt="Profile Picture"
								className="object-cover aspect-square w-full h-full rounded-lg"
							/>
						</div>
					</div>
					<div className="flex flex-col items-center">
						<label className="mb-2 text-sm font-medium text-gray-600">
							স্বাক্ষর
						</label>
						<div className="max-w-[300px] min-w-[300px] w-full min-h-[80px] h-full max-h-[80px]">
							<img
								src={signature}
								alt="Signature"
								className="object-cover  w-full h-full rounded-lg"
							/>
						</div>
					</div>
				</div>
				<div className="grid grid-cols-1 gap-4 mt-6 md:grid-cols-2">
					<div>
						<strong>পূর্ণ নাম:</strong> {fullname}
					</div>
					<div>
						<strong>পিতার নাম:</strong> {fathername}
					</div>
					<div>
						<strong>মাতার নাম:</strong> {mothername}
					</div>
					<div>
						<strong>ইমেইল:</strong> {email}
					</div>
					<div>
						<strong>ফোন:</strong> {phone}
					</div>
					<div>
						<strong>বাড়ি নং:</strong> {house_no}
					</div>
					<div>
						<strong>গ্রাম:</strong> {village}
					</div>
					<div>
						<strong>পোস্ট অফিস:</strong> {po}
					</div>
					<div>
						<strong>থানা:</strong> {ps}
					</div>
					<div>
						<strong>জেলা:</strong> {district}
					</div>
					<div>
						<strong>এনআইডি নম্বর:</strong> {nid_number}
					</div>
				</div>
				<h3 className="mt-6 text-lg font-medium text-gray-800">
					ব্যাংক তথ্য
				</h3>
				<div className="grid grid-cols-1 gap-4 md:grid-cols-2">
					<div>
						<strong>হোল্ডারের নাম:</strong>{" "}
						{bank_account_holder_name}
					</div>
					<div>
						<strong>অ্যাকাউন্ট নম্বর:</strong> {bank_account_number}
					</div>
					<div>
						<strong>ব্যাংকের নাম:</strong> {bank_name}
					</div>
					<div>
						<strong>শাখা:</strong> {bank_branch}
					</div>
					<div>
						<strong>জেলা:</strong> {bank_district}
					</div>
					<div>
						<strong>রাউটিং নম্বর:</strong> {routing_number}
					</div>
				</div>
			</div>
		</div>
	);
};

function RowCard({
	agent,
	agents,
	setAgents,
	index,
}: {
	agent: User;
	index: number;
	agents: User[];
	setAgents: (agents: User[]) => void;
}) {
	const [loading, setLoading] = useState(false);
	const [isVisible, setIsVisible] = useState(false);
	async function handleDelete() {
		setLoading(true);
		const response = await fetch("/api/admin/funds/get-agents", {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({
				agentId: agent._id,
			}),
		});
		const data = await response.json();
		if (response.ok) {
			toast.success(data.message);
			const temp = [...agents];
			temp.splice(index, 1);
			setAgents(temp);
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	}

	async function handleVerify() {
		setLoading(true);
		const response = await fetch("/api/admin/funds/approve-admin", {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({
				agentId: agent._id,
			}),
		});
		const data = await response.json();
		if (response.ok) {
			toast.success(data.message);
			const temp = [...agents];
			temp[index].admin_verified = true;
			setAgents(temp);
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	}
	return (
		<div
			className={`w-full flex p-[12px]  items-center border-b justify-between ${
				index % 2 === 0 ? "bg-white" : "bg-[#FAFAFA]"
			}`}
		>
			<Modal
				agent={agent}
				is_visible={isVisible}
				onClose={() => setIsVisible(false)}
			/>
			<div className="flex w-full items-center gap-[12px]">
				<img
					src={agent.profile_picture}
					alt={agent.fullname}
					width={40}
					height={40}
					className="rounded-full aspect-square object-cover"
				/>
				<div className="text-[#181D27] text-wrap font-[500] text-[14px]">
					<span className="">{agent.fullname}</span>
				</div>
			</div>
			<div className="text-[#535862] hidden lg:flex w-full text-wrap text-[14px]">
				<span className="">{agent.phone}</span>
			</div>
			<div className="text-[#535862] hidden lg:flex w-full text-wrap text-[14px]">
				<span className="">
					৳{new BengaliNumber(agent.amount).bngValue}
				</span>
			</div>
			<div
				onClick={() => setIsVisible(true)}
				className="text-[#750cff] hover:text-[#9d52ff] cursor-pointer font-bold flex w-full text-wrap text-[14px]"
			>
				বিস্তারিত দেখুন
			</div>

			{loading ? (
				<Spin size="large" />
			) : (
				<div className="flex w-full justify-end items-end flex-row gap-x-8">
					<button
						onClick={() => {
							if (agent.admin_verified) return;
							handleVerify();
						}}
						className=" justify-end flex items-center gap-1 font-semibold rounded-[8px]"
						name="Verify"
						title={
							agent.admin_verified
								? "ভেরিফাই করা হয়েছে"
								: "ভেরিফাই করুন"
						}
						disabled={agent.admin_verified}
					>
						{agent.admin_verified ? (
							<CheckCheck className="text-green-500" size={20} />
						) : (
							<Check className="hover:text-blue-300" size={20} />
						)}
					</button>
					<button
						onClick={handleDelete}
						className=" justify-end flex items-center gap-1 font-semibold rounded-[8px]"
						name="Delete"
						title="মুছে ফেলুন"
					>
						<Trash className="hover:text-red-500" size={20} />
					</button>
				</div>
			)}
		</div>
	);
}

function TopTitle({ router }: { router: AppRouterInstance }) {
	return (
		<div className="w-full flex md:flex-row flex-col justify-between gap-[20px]">
			<div className="pb-[20px]">
				<div className="font-semibold text-[#535862] text-[24px]">
					এজেন্ট ম্যানেজমেন্ট
				</div>
				<div className=" text-[#535862] text-[16px]">
					আপনি এখানে সকল এজেন্টের তালিকা দেখতে পারবেন
				</div>
			</div>
		</div>
	);
}

function SearchBar({
	search_text,
	setSearchText,
	handleSearch,
	agents,
	days,
	setDays,
}: {
	search_text: string;
	setSearchText: (text: string) => void;
	handleSearch: () => void;
	agents: User[];
	days: number;
	setDays: (days: number) => void;
}) {
	async function handleExcelDownload() {
		const data = agents.map((agent) => ({
			Name: agent.fullname,
			Email: agent.email,
			Amount: agent.amount,
		}));

		const worksheet = XLSX.utils.json_to_sheet(data);
		const workbook = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(workbook, worksheet, "Agents");

		const excelBuffer = XLSX.write(workbook, {
			bookType: "xlsx",
			type: "array",
		});
		const blob = new Blob([excelBuffer], {
			type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		});
		const url = window.URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `agents${new Date().toISOString()}.xlsx`;
		a.click();
		window.URL.revokeObjectURL(url);
	}
	return (
		<div className="flex flex-col">
			<div className="w-full px-4 pb-2 border-b mt-2 flex md:flex-row flex-col justify-between items-center gap-[20px]">
				<div className="w-full font-semibold text-[#181D27] text-[18px]">
					এজেন্ট
				</div>
				<button
					onClick={handleExcelDownload}
					className="border-[1px] w-full lg:w-fit hover:bg-slate-50 justify-center items-center flex gap-1 border-[#D5D7DA] rounded-[8px] py-[8px] px-[14px] "
				>
					<Image
						src="/assets/Icons/download-cloud-01.svg"
						alt="search"
						width={20}
						height={20}
						className=""
					/>
					<span>ডাউনলোড</span>
				</button>
			</div>
			<div className="w-full justify-between lg:justify-end px-4 pb-2 border-b mt-2 flex md:flex-row flex-col  items-center gap-[20px]">
				<div className="relative ">
					<Image
						src="/assets/Icons/search-lg.svg"
						alt="search"
						width={20}
						height={20}
						className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
					/>
					<input
						type="text"
						placeholder="অনুসন্ধান করুন"
						name="search"
						value={search_text}
						onChange={(e) => setSearchText(e.target.value)}
						onKeyDown={(e) => {
							if (e.key === "Enter") handleSearch();
						}}
						className="border-[1px] border-[#D5D7DA] rounded-[8px] h-[40px] pl-[40px] pr-[12px] w-full md:min-w-[320px]"
					/>
				</div>
			</div>
		</div>
	);
}

function SortingBar() {
	return (
		<div className="w-full flex text-[12px] p-[12px] items-center text-[#717680] bg-[#FAFAFA]  justify-between">
			<div className="w-full font-semibold ">এজেন্ট</div>
			<div className="w-full hidden lg:flex font-semibold ">ফোন</div>
			<div className="w-full hidden lg:flex font-semibold ">পরিমাণ</div>
			<div className="w-full flex font-semibold ">বিস্তারিত</div>
			<div className="w-full font-semibold text-end ">প্রক্রিয়া</div>
		</div>
	);
}
