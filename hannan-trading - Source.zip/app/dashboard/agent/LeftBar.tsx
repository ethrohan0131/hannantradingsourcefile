"use client";
import { useRouter, usePathname } from "next/navigation";
import Image from "next/image";
import { useUser, useClerk } from "@clerk/nextjs";
import { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { Spin } from "antd";
import { X, Menu, Camera } from "lucide-react";
import districtsData from "../../../public/data/district.json";
import "./styles.css";

interface User {
	_id: string;
	fullname: string;
	fathername: string;
	mothername: string;
	email: string;
	phone: string;
	house_no: string;
	village: string;
	po: string;
	ps: string;
	district: string;
	nid_number: string;
	profile_picture: string;
	signature: string;
	clerkId: string;
	role: string[];
	admin_verified: boolean;
	amount: number;
}

const Modal = ({
	agent,
	is_visible,
	onClose,
	setAgent,
}: {
	agent: User;
	is_visible: boolean;
	onClose: () => void;
	setAgent: any;
}) => {
	const modalRef = useRef<HTMLDivElement>(null);
	const router = useRouter();

	const [profilePicture, setProfilePicture] = useState(agent.profile_picture);
	const [profilePictureLoading, setProfilePictureLoading] = useState(false);
	const [signature, setSignature] = useState(agent.signature);
	const [signatureLoading, setSignatureLoading] = useState(false);
	const [loading, setLoading] = useState(false);

	const handleProfileImageChange = async (
		event: React.ChangeEvent<HTMLInputElement>
	) => {
		const file = event.target.files?.[0];
		if (file) {
			const data = new FormData();
			data.append("file", file);
			data.append("upload_preset", "kefexupz");
			setProfilePictureLoading(true);
			const res = await fetch(`/api/imgUpload`, {
				method: "POST",
				body: data,
			});
			const imageResponse = await res.json();
			if (imageResponse.status === 200) {
				setProfilePicture(imageResponse.uploadedImageData.url);
			} else {
				toast.error("Failed to upload profile picture");
			}
			setProfilePictureLoading(false);
		}
	};

	const handleSignatureImageChange = async (
		event: React.ChangeEvent<HTMLInputElement>
	) => {
		const file = event.target.files?.[0];
		if (file) {
			const data = new FormData();
			data.append("file", file);
			data.append("upload_preset", "kefexupz");
			setSignatureLoading(true);
			const res = await fetch(`/api/imgUpload`, {
				method: "POST",
				body: data,
			});
			const imageResponse = await res.json();
			if (imageResponse.status === 200) {
				setSignature(imageResponse.uploadedImageData.url);
			} else {
				toast.error("Failed to upload signature");
			}
			setSignatureLoading(false);
		}
	};

	const handleOutsideClick = (e: React.MouseEvent) => {
		if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
			onClose();
		}
	};

	if (!is_visible) return null;

	const handleInputChange = (field: keyof User, value: string) => {
		setAgent((prev: User) => ({
			...prev,
			[field]: value,
		}));
	};

	async function updateProfile() {
		if (profilePictureLoading || signatureLoading) {
			toast.error("Please wait until images are uploaded");
			return;
		}

		if (
			!agent.fullname ||
			!agent.fathername ||
			!agent.mothername ||
			!agent.phone ||
			!agent.district ||
			!agent.house_no ||
			!agent.village ||
			!agent.po ||
			!agent.ps ||
			!agent.nid_number
		) {
			toast.error("Please fill all required fields");
			return;
		}

		const newUser = {
			fullname: agent.fullname,
			fathername: agent.fathername,
			mothername: agent.mothername,
			phone: agent.phone,
			house_no: agent.house_no,
			village: agent.village,
			po: agent.po,
			ps: agent.ps,
			district: agent.district,
			nid_number: agent.nid_number,
			profile_picture: profilePicture
				? profilePicture
				: agent.profile_picture,
			signature: signature ? signature : agent.signature,
		};
		setLoading(true);
		const res = await fetch(`/api/profile`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ newUser }),
		});
		const data = await res.json();
		if (res.ok) {
			setAgent(data.updatedUser);
			toast.success(data.message);
			router.push("/agent-approval");
			onClose();
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	}

	return (
		<div
			onClick={handleOutsideClick}
			className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-md"
		>
			<div
				ref={modalRef}
				className="relative mx-6 w-full max-w-3xl p-6 bg-white rounded-lg shadow-lg max-h-[90vh] overflow-y-auto custom-scrollbar"
			>
				<button
					className="absolute top-3 right-3 text-gray-500 hover:text-gray-800"
					onClick={onClose}
					title="বন্ধ করুন"
				>
					<X className="w-6 h-6" />
				</button>
				<h2 className="mb-6 text-xl font-semibold text-center text-gray-800">
					প্রোফাইল তথ্য পাল্টান
				</h2>
				<div className="grid gap-4 md:grid-cols-2">
					<div className="flex flex-col items-center">
						<label className="mb-2 text-sm font-medium text-gray-600">
							প্রোফাইল ছবি
						</label>
						<div
							className={`max-w-[250px] min-w-[250px]  w-full h-full min-h-[250px] max-h-[250px] ${
								!profilePictureLoading && "relative"
							} `}
						>
							{profilePictureLoading ? (
								<Spin size="large" />
							) : (
								<>
									<label className="absolute inset-0 rounded-lg bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
										<Camera className="text-white w-8 h-8" />
										<input
											title="profile_picture"
											type="file"
											accept="image/*"
											className="hidden"
											onChange={handleProfileImageChange}
										/>
									</label>
									<img
										src={profilePicture}
										alt="Profile Picture"
										className="object-fit aspect-square w-full h-full rounded-lg"
									/>
								</>
							)}
						</div>
					</div>
					<div className="flex flex-col items-center">
						<label className="mb-2 text-sm font-medium text-gray-600">
							স্বাক্ষর
						</label>
						<div className="max-w-[250px] min-w-[250px] w-full h-full min-h-[80px] max-h-[80px] relative">
							{signatureLoading ? (
								<div className="w-full h-full items-cente justify-center">
									<Spin size="large" />
								</div>
							) : (
								<>
									<label className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer rounded-lg">
										<Camera className="text-white w-8 h-8" />
										<input
											title="signature"
											type="file"
											accept="image/*"
											className="hidden"
											onChange={
												handleSignatureImageChange
											}
										/>
									</label>
									<img
										src={signature}
										alt="Signature"
										className="object-cover w-full h-full rounded-lg"
									/>
								</>
							)}
						</div>
					</div>
				</div>
				<div className="mt-6">
					<div className="grid grid-cols-1 gap-4 md:grid-cols-2">
						{[
							{
								label: "পূর্ণ নাম",
								field: "fullname",
								value: agent.fullname,
							},
							{
								label: "পিতার নাম",
								field: "fathername",
								value: agent.fathername,
							},
							{
								label: "মাতার নাম",
								field: "mothername",
								value: agent.mothername,
							},
							{
								label: "ইমেইল",
								field: "email",
								value: agent.email,
								disabled: true,
							},
							{
								label: "ফোন",
								field: "phone",
								value: agent.phone,
							},
							{
								label: "বাড়ি নং",
								field: "house_no",
								value: agent.house_no,
							},
							{
								label: "গ্রাম",
								field: "village",
								value: agent.village,
							},
							{
								label: "পোস্ট অফিস",
								field: "po",
								value: agent.po,
							},
							{ label: "থানা", field: "ps", value: agent.ps },
							{
								label: "জেলা",
								field: "district",
								value: agent.district,
								isSelect: true,
							},
							{
								label: "এনআইডি নম্বর",
								field: "nid_number",
								value: agent.nid_number,
							},
						].map(({ label, field, value, disabled, isSelect }) => (
							<div
								key={field}
								className="flex items-center gap-4"
							>
								<label className="w-32 text-sm font-medium text-gray-600">
									{label}
								</label>
								{isSelect ? (
									<select
										title="district"
										className="flex-1 p-2 border rounded-lg "
										value={value}
										onChange={(e) =>
											handleInputChange(
												field as keyof User,
												e.target.value
											)
										}
									>
										{districtsData.districts.map(
											(district) => (
												<option
													key={district.id}
													value={district.name}
												>
													{district.bn_name}
												</option>
											)
										)}
									</select>
								) : (
									<input
										title="district"
										type="text"
										className="flex-1 p-2 border rounded-lg"
										value={value}
										disabled={disabled}
										onChange={(e) =>
											handleInputChange(
												field as keyof User,
												e.target.value
											)
										}
									/>
								)}
							</div>
						))}
					</div>
				</div>
				<div className="w-full lg:justify-end flex gap-4 mt-4 lg:mt-0">
					{loading && <Spin size="large" />}
					{!loading && (
						<>
							<button
								onClick={onClose}
								className="px-4 w-full lg:w-fit py-2 text-black border rounded-lg hover:bg-gray-100"
							>
								বাতিল করুন
							</button>

							<button
								onClick={updateProfile}
								className="bg-[#7F56D9] w-full lg:w-fit hover:bg-[#6d49b9] text-white rounded-lg px-[14px] py-[10px] font-semibold"
							>
								সেভ করুন
							</button>
						</>
					)}
				</div>
			</div>
		</div>
	);
};

export default function LeftPanel() {
	const router = useRouter();
	const pathname = usePathname();
	const { isLoaded, user } = useUser();
	const [profile, setProfile] = useState<User | null>(null);
	const [fetchingProfile, setFetchingProfile] = useState(false);
	const [isSidebarOpen, setIsSidebarOpen] = useState(false);
	const [profileShow, setProfileShow] = useState(false);
	const { signOut } = useClerk();
	const [menuOpen, setMenuOpen] = useState(false);

	useEffect(() => {
		if (!isLoaded) return;
		async function fetchUser() {
			if (!user) return;
			setFetchingProfile(true);
			const res = await fetch(
				`/api/profile?email=${user.emailAddresses[0].emailAddress}`
			);
			if (res.ok) {
				const data = await res.json();
				setProfile(data);
			} else {
				toast.error("Failed to fetch user profile");
			}
			setFetchingProfile(false);
		}
		fetchUser();
	}, [isLoaded, user]);

	return (
		<>
			{profile && (
				<Modal
					agent={profile}
					is_visible={menuOpen}
					onClose={() => setMenuOpen(false)}
					setAgent={setProfile}
				/>
			)}
			<div className="lg:hidden bg-white flex items-center justify-between p-4">
				<Image
					src="/assets/logo.svg"
					alt="Logo"
					width={100}
					height={100}
					className="cursor-pointer"
					onClick={() => router.push("/")}
				/>
				<Menu
					onClick={() => setIsSidebarOpen(true)}
					className="text-gray-700 cursor-pointer"
					size={24}
				/>
			</div>

			<div
				className={`fixed lg:static top-0 left-0 h-full w-[296px] max-w-[296px] bg-white border-r border-gray-200 z-50 p-5 transform ${
					isSidebarOpen ? "translate-x-0" : "-translate-x-full"
				} lg:translate-x-0 transition-transform duration-300`}
			>
				<div className="h-full flex flex-col justify-between">
					<div>
						<div className="flex justify-between">
							<Image
								src="/assets/logo.svg"
								alt="Logo"
								width={100}
								height={100}
								className="cursor-pointer"
								onClick={() => router.push("/")}
							/>
							<div className="lg:hidden flex justify-end mb-4">
								<X
									onClick={() => setIsSidebarOpen(false)}
									className="text-gray-700 cursor-pointer"
									size={24}
								/>
							</div>
						</div>
						<ul className="mt-8 px-1">
							<li className="mb-2">
								<div
									onClick={() =>
										router.push("/dashboard/agent/home")
									}
									className={`flex cursor-pointer rounded-lg p-2 flex-row items-center gap-2 ${
										pathname.startsWith(
											"/dashboard/agent/home"
										)
											? "bg-[#FAFAFA]"
											: ""
									}`}
								>
									<Image
										src="/assets/Icons/home-line.svg"
										width={24}
										height={24}
										alt="Home"
									/>
									<span className="text-[16px] text-[#252B37] hover:text-[#384153] font-semibold">
										হোম
									</span>
								</div>
							</li>
							<li className="mb-2">
								<div
									onClick={() =>
										router.push("/dashboard/agent/events")
									}
									className={`flex cursor-pointer rounded-lg p-2 flex-row items-center gap-2 ${
										pathname.startsWith(
											"/dashboard/agent/events"
										)
											? "bg-[#FAFAFA]"
											: ""
									}`}
								>
									<Image
										src="/assets/Icons/rows-01.svg"
										width={24}
										height={24}
										alt="Events"
									/>
									<span className="text-[16px] text-[#252B37] hover:text-[#384153] font-semibold">
										ইভেন্ট
									</span>
								</div>
							</li>
							<li className="mb-2">
								<div
									onClick={() =>
										router.push(
											"/dashboard/agent/investors"
										)
									}
									className={`flex cursor-pointer rounded-lg p-2 flex-row items-center gap-2 ${
										pathname.startsWith(
											"/dashboard/agent/investors"
										)
											? "bg-[#FAFAFA]"
											: ""
									}`}
								>
									<Image
										src="/assets/Icons/users-01.svg"
										width={24}
										height={24}
										alt="Events"
									/>
									<span className="text-[16px] text-nowrap text-[#252B37] hover:text-[#384153] font-semibold">
										এজেন্ট কো-ইনভেস্টর
									</span>
								</div>
							</li>
						</ul>
					</div>
					<div className="w-full border p-2 bg-white rounded-lg">
						{profile && (
							<div className="w-full justify-between flex items-start">
								<div className="flex items-center gap-2">
									<img
										src={profile.profile_picture}
										alt="Profile Picture"
										width={40}
										height={40}
										className="rounded-full aspect-square"
									/>
									<div>
										<p className="text-[#252B37] font-semibold">
											{profile.fullname}
										</p>
										<p className="text-[#6B7280] text-[14px]">
											এজেন্ট
										</p>
									</div>
								</div>
								<div className="">
									<div className="relative">
										{profileShow && (
											<div className="absolute -left-52 lg:left-10 lg:bottom-0 bottom-10   border rounded-lg shadow-lg">
												<ul>
													<li className=" w-full flex flex-col items-start">
														<div
															onClick={() => {
																setMenuOpen(
																	!menuOpen
																);
																setProfileShow(
																	false
																);
																setIsSidebarOpen(
																	false
																);
															}}
															className="px-2 w-full rounded-t-lg flex border-b bg-white hover:bg-gray-100 cursor-pointer"
														>
															<Image
																src="/assets/Icons/settings-01.svg"
																width={24}
																height={24}
																alt="Logout"
																className="cursor-pointer hover:bg-slate-50 rounded-lg"
															/>
															<div className="text-[#414651] select-none px-2 py-2 font-semibold text-[14px] text-nowrap">
																একাউন্ট সেটিংস
															</div>
														</div>
														<div className=" rounded-lg border-b bg-white">
															<div className="text-[#535862] px-4 py-2 font-semibold text-[12px] text-nowrap">
																একাউন্ট পাল্টান
															</div>
															<div className="flex justify-between px-4 py-2 cursor-default bg-slate-50 w-64">
																<div className="flex">
																	<img
																		src={
																			profile.profile_picture
																		}
																		alt="Profile Picture"
																		width={
																			40
																		}
																		height={
																			40
																		}
																		className="rounded-full h-[40px] w-[40px] aspect-square"
																	/>

																	<div className="flex text-nowrap flex-col ml-2 h-full w-full items-start justify-between">
																		<div className="text-[#252B37] font-semibold">
																			{
																				profile.fullname
																			}
																		</div>
																		<div className="text-[#6B7280] text-[14px]">
																			এজেন্ট
																		</div>
																	</div>
																</div>

																<div className="w-4 h-4 rounded-full border bg-violet-600 border-gray-400 flex items-center justify-center">
																	<div className="w-2 h-2 bg-white rounded-full"></div>
																</div>
															</div>
															{profile.role.includes(
																"admin"
															) && (
																<div
																	onClick={() => {
																		router.push(
																			"/dashboard/admin/home"
																		);
																	}}
																	className="flex px-4 py-2 cursor-pointer justify-between hover:bg-slate-50 w-64"
																>
																	<div className="flex">
																		<img
																			src={
																				profile.profile_picture
																			}
																			alt="Profile Picture"
																			width={
																				40
																			}
																			height={
																				40
																			}
																			className="rounded-full h-[40px] w-[40px] aspect-square"
																		/>

																		<div className="flex text-nowrap flex-col ml-2 h-full w-full items-start justify-between">
																			<div className="text-[#252B37] font-semibold">
																				{
																					profile.fullname
																				}
																			</div>
																			<div className="text-[#6B7280] text-[14px]">
																				সুপার
																				এডমিন
																			</div>
																		</div>
																	</div>
																	<div className="w-4 h-4 rounded-full border border-gray-400 flex items-center justify-center">
																		<div className="w-2 h-2 bg-white rounded-full"></div>
																	</div>
																</div>
															)}
														</div>
														<div
															onClick={() => {
																signOut();
																router.push(
																	"/"
																);
															}}
															className="bg-[#FAFAFA] cursor-pointer hover:bg-slate-100 w-full rounded-b-lg px-4 flex "
														>
															<Image
																src="/assets/Icons/log-out-01.svg"
																width={24}
																height={24}
																alt="Logout"
																className="cursor-pointer hover:bg-slate-50 rounded-lg"
															/>
															<div className="text-[#414651] text-[14px] font-semibold p-2">
																লগ আউট
															</div>
														</div>
													</li>
												</ul>
											</div>
										)}
										<Image
											src="/assets/Icons/chevron-selector-vertical2.svg"
											width={24}
											height={24}
											alt="Dropdown"
											className="cursor-pointer hover:bg-slate-50 rounded-lg"
											onClick={() =>
												setProfileShow(!profileShow)
											}
										/>
									</div>
								</div>
							</div>
						)}
						{fetchingProfile && (
							<div className="flex items-center gap-2">
								<Spin />
							</div>
						)}
					</div>
				</div>
			</div>

			{isSidebarOpen && (
				<div
					className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
					onClick={() => setIsSidebarOpen(false)}
				></div>
			)}
		</>
	);
}
