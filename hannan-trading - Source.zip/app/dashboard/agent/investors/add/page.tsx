"use client";
import { useRouter, useParams } from "next/navigation";
import Image from "next/image";
import { useState, useEffect, useRef } from "react";
import toast from "react-hot-toast";
import { Spin } from "antd";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";
import { X } from "lucide-react";
import { BengaliNumber } from "to-bengali";

interface Bank {
	_id: string;
	bank_account_number: string;
	bank_account_holder_name: string;
	bank_name: string;
	bank_district: string;
	bank_branch: string;
	routing_number: string;
}

interface Event {
	_id: string;
	name: string;
	tagline: string;
	banner: string;
	roi: number;
	minimum_deposit: number;
	maximum_deposit: number;
	duration: number;
	start_date: Date;
}

interface Investor {
	name: string;
	nid: string;
	nominee_name: string;
	nominee_nid: string;
	payment_method: string;
	date: Date;
	amount: number;
	percentage: number;
	phone: string;
}

export default function Page() {
	const router = useRouter();

	const [loading, setLoading] = useState<boolean>(true);
	return (
		<div className="flex flex-col h-full w-full p-4 lg:p-24">
			<AddInvestor router={router} />
		</div>
	);
}

function AddInvestor({ router }: { router: AppRouterInstance }) {
	const [name, setName] = useState<string>("");
	const [nid, setNid] = useState<string>("");
	const [nominee_name, setNomineeName] = useState<string>("");
	const [nominee_nid, setNomineeNid] = useState<string>("");
	const [payment_method, setPaymentMethod] = useState<string>("ব্যাংক");
	const [date, setDate] = useState<Date>(new Date());
	const [amount, setAmount] = useState<string>("");
	const [percentage, setPercentage] = useState<string>("");
	const [phone, setPhone] = useState<string>("");
	const [loading, setLoading] = useState<boolean>(false);

	async function add_investor() {
		if (
			!name ||
			!nid ||
			!nominee_name ||
			!nominee_nid ||
			!payment_method ||
			!date ||
			!amount ||
			!percentage ||
			!phone
		) {
			toast.error("সব কয়টি বক্স পূরণ করুন");
			return;
		}
		console.log(payment_method);
		if (
			payment_method !== "ব্যাংক" &&
			payment_method !== "বিকাশ" &&
			payment_method !== "নগদ টাকা"
		) {
			toast.error("ভুল পেমেন্ট মেথড");
			return;
		}
		setLoading(true);
		const newInvestor = {
			name,
			nid,
			nominee_name,
			nominee_nid,
			payment_method,
			date,
			amount: parseInt(amount),
			percentage: parseInt(percentage),
			phone,
		};

		const res = await fetch("/api/agent/new-investor", {
			method: "POST",
			body: JSON.stringify({ investorSingle: newInvestor }),
		});

		const data = await res.json();

		if (res.status === 200) {
			toast.success(data.message);
			setName("");
			setNid("");
			setNomineeName("");
			setNomineeNid("");
			setPaymentMethod("ব্যাংক");
			setDate(new Date());
			setAmount("");
			setPercentage("");
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	}

	return (
		<div className="h-full flex-col space-y-[20px]  w-full">
			<div className="flex flex-col w-full gap-[20px]">
				<div className="flex flex-col gap-[6px]">
					<div className="text-[#414651]">কো-ইনভেস্টরের নাম *</div>
					<input
						type="text"
						className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
						placeholder="ইনভেস্টরের নাম দিন"
						value={name}
						onChange={(e) => setName(e.target.value)}
					/>
				</div>

				<div className="flex flex-col gap-[6px]">
					<div className="text-[#414651]">
						জাতীয় পরিচয় পত্র নং *
					</div>
					<input
						type="text"
						className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
						placeholder="জাতীয় পরিচয় পত্র নং দিন"
						value={nid}
						onChange={(e) => setNid(e.target.value)}
					/>
				</div>
				<div className="flex flex-col gap-[6px]">
					<div className="text-[#414651]">ফোন নম্বর *</div>
					<input
						type="text"
						className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
						placeholder="ফোন নম্বর দিন"
						value={phone}
						onChange={(e) => setPhone(e.target.value)}
					/>
				</div>

				<div className="flex flex-col gap-[6px]">
					<div className="text-[#414651]">নমিনির নাম *</div>
					<input
						type="text"
						className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
						placeholder="নমিনির নাম দিন"
						value={nominee_name}
						onChange={(e) => setNomineeName(e.target.value)}
					/>
				</div>

				<div className="flex flex-col gap-[6px]">
					<div className="text-[#414651]">
						নমিনির জাতীয় পরিচয় পত্র নং *
					</div>
					<input
						type="text"
						className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
						placeholder="নমিনির জাতীয় পরিচয় পত্র নং দিন"
						value={nominee_nid}
						onChange={(e) => setNomineeNid(e.target.value)}
					/>
				</div>

				<div className="flex flex-col items-center lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full">
					<div className="flex w-full flex-col gap-[6px]">
						<div className="text-[#414651]">পেমেন্ট মেথড *</div>
						<select
							name="payment_method"
							title="payment_method"
							className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
							value={payment_method}
							onChange={(e) => setPaymentMethod(e.target.value)}
						>
							<option value="ব্যাংক">ব্যাংক</option>
							<option value="বিকাশ">বিকাশ</option>
							<option value="নগদ টাকা">নগদ টাকা</option>
						</select>
					</div>

					<div className="flex w-full flex-col gap-[6px]">
						<div className="text-[#414651]">জমার তারিখ *</div>
						<input
							type="date"
							name="date"
							title="date"
							className="border border-[#D5D7DA] rounded-lg px-[14px] py-[8px]"
							value={date.toISOString().split("T")[0]}
							onChange={(e) => setDate(new Date(e.target.value))}
						/>
					</div>
				</div>
				<div className="flex flex-col items-center lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full">
					<div className="flex w-full flex-col gap-[6px]">
						<div className="text-[#414651]">পরিমাণ *</div>
						<input
							type="number"
							className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
							placeholder="পরিমাণ দিন"
							value={amount}
							onChange={(e) => setAmount(e.target.value)}
						/>
					</div>

					<div className="flex w-full flex-col gap-[6px]">
						<div className="text-[#414651]"> % পারছেন্টেজ *</div>
						<input
							type="number"
							className="border border-[#D5D7DA] rounded-lg px-[14px] py-[10px]"
							placeholder=" % পারছেন্টেজ দিন"
							value={percentage}
							onChange={(e) => setPercentage(e.target.value)}
						/>
					</div>
				</div>
				{loading && <Spin size="large" />}

				{!loading && (
					<div className="flex justify-end gap-4 p-4">
						<button
							onClick={() => router.back()}
							className="hover:bg-slate-50 border text-black rounded-lg px-[14px] py-[6px] font-semibold"
						>
							বাতিল করুন
						</button>
						<button
							onClick={add_investor}
							className="bg-[#6941C6] hover:bg-[#5d39af] text-white rounded-lg px-[14px] py-[6px] font-semibold"
						>
							যুক্ত করুন
						</button>
					</div>
				)}
			</div>
		</div>
	);
}
