import { NextResponse } from "next/server";
import { connectToDB } from "@/lib/mongoDB";
import OTP from "@/models/OTP";
import User from "@/models/User";
import { createTransport } from "nodemailer";

function generateOTP() {
	return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendEmail(email: string, otp: string) {
	const transporter = createTransport({
		service: "gmail",
		auth: {
			user: process.env.GMAIL_USER,
			pass: process.env.GMAIL_APP_PASSWORD,
		},
	});

	const mailOptions = {
		from: `"Hannan Trading" <${process.env.GMAIL_USER}>`,
		to: email,
		subject: "আপনার OTP কোড",
		html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
          }
          .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          }
          .header {
            background-color: #007bff;
            color: #ffffff;
            padding: 20px;
            text-align: center;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
          }
          .content {
            padding: 20px;
            text-align: center;
          }
          .content h2 {
            color: #333;
            margin-bottom: 10px;
          }
          .otp {
            font-size: 28px;
            font-weight: bold;
            color: #007bff;
            margin: 20px 0;
          }
          .footer {
            background-color: #f4f4f4;
            padding: 10px;
            text-align: center;
            font-size: 12px;
            color: #666;
          }
          .footer a {
            color: #007bff;
            text-decoration: none;
          }
        </style>
      </head>
      <body>
        <div class="email-container">
          <div class="header">
            <h1>হান্নান ট্রেডিং</h1>
          </div>
          <div class="content">
            <h2>আপনার OTP কোড</h2>
            <p>নিচের কোডটি ব্যবহার করে সাইনআপ প্রক্রিয়া সম্পন্ন করুন। এই কোডটি ৫ মিনিটের মধ্যে মেয়াদ উত্তীর্ণ হবে।</p>
            <div class="otp">${otp}</div>
            <p>যদি আপনি এই কোডটির অনুরোধ না করে থাকেন, তাহলে দয়া করে এই ইমেলটি উপেক্ষা করুন।</p>
          </div>
          <div class="footer">
            <p>সহায়তার প্রয়োজন? <a href="mailto:support@hannantrading.org">সাপোর্টের সাথে যোগাযোগ করুন</a></p>
            <p>&copy; ${new Date().getFullYear()} হান্নান ট্রেডিং। সর্বস্বত্ব সংরক্ষিত।</p>
          </div>
        </div>
      </body>
      </html>
    `,
	};

	return transporter.sendMail(mailOptions);
}

export const POST = async (req: Request) => {
	try {
		await connectToDB();

		const { email } = await req.json();

		if (!email) {
			return NextResponse.json(
				{ message: "Invalid email" },
				{ status: 400 }
			);
		}

		const existingUser = await User.findOne({ email });

		if (existingUser) {
			return NextResponse.json(
				{ message: "User already exists" },
				{ status: 400 }
			);
		}

		const otp = generateOTP();

		await OTP.deleteMany({ email });

		const newOTP = new OTP({
			email,
			otp,
		});

		await newOTP.save();

		await sendEmail(email, otp);

		return NextResponse.json(
			{ message: "OTP sent successfully" },
			{ status: 201 }
		);
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};

export const PUT = async (req: Request) => {
	try {
		await connectToDB();

		const { email, otp } = await req.json();

		if (!email) {
			return NextResponse.json(
				{ message: "Invalid email" },
				{ status: 400 }
			);
		}

		if (!otp) {
			return NextResponse.json(
				{ message: "Invalid OTP" },
				{ status: 400 }
			);
		}

		const existingOTP = await OTP.findOne({ email, otp, valid: true });

		if (!existingOTP) {
			return NextResponse.json(
				{ message: "Invalid OTP" },
				{ status: 400 }
			);
		}

		if (existingOTP) {
			const currentTime = new Date().getTime();
			const otpTime = new Date(existingOTP.createdAt).getTime();
			const timeDifference = (currentTime - otpTime) / 1000 / 60; // time difference in minutes

			if (timeDifference > 5) {
				return NextResponse.json(
					{ message: "OTP expired" },
					{ status: 400 }
				);
			}
		}

		// await OTP.updateOne(
		// 	{
		// 		email,
		// 		otp,
		// 	},
		// 	{
		// 		valid: false,
		// 	}
		// );

		return NextResponse.json(
			{ message: "OTP verified successfully" },
			{ status: 200 }
		);
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};
