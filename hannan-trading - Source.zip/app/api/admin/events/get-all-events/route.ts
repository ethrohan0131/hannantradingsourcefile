import { NextResponse } from "next/server";
import { connectToDB } from "@/lib/mongoDB";
import Event from "@/models/Event";
import Transaction from "@/models/Transaction";
import { currentUser } from "@clerk/nextjs/server";

export const POST = async (req: Request) => {
	try {
		await connectToDB();

		const user = await currentUser();

		if (!user) {
			return NextResponse.json(
				{ message: "Unauthorized" },
				{ status: 401 }
			);
		}

		const role: string[] = user.publicMetadata.role as string[];

		if (!role.includes("admin")) {
			return NextResponse.json(
				{ message: "Unauthorized" },
				{ status: 401 }
			);
		}

		const { page, roi_based_sorting, date_based_sorting, search_text } =
			await req.json();

		if (!page) {
			return NextResponse.json(
				{ message: "Page number is required" },
				{ status: 400 }
			);
		}

		if (
			roi_based_sorting &&
			roi_based_sorting !== "asc" &&
			roi_based_sorting !== "desc"
		) {
			return NextResponse.json(
				{ message: "Invalid sorting value" },
				{ status: 400 }
			);
		}

		if (
			date_based_sorting &&
			date_based_sorting !== "asc" &&
			date_based_sorting !== "desc"
		) {
			return NextResponse.json(
				{ message: "Invalid sorting value" },
				{ status: 400 }
			);
		}

		const sortOrder = (order: string) => (order === "asc" ? 1 : -1);

		let query = {};
		let sortCondition = {};

		if (search_text) {
			query = {
				$or: [
					{ name: { $regex: search_text, $options: "i" } },
					{ tagline: { $regex: search_text, $options: "i" } },
					{
						$expr: {
							$regexMatch: {
								input: { $toString: "$roi" },
								regex: search_text,
								options: "i",
							},
						},
					},
				],
			};
		}

		if (roi_based_sorting === "desc") {
			sortCondition = { roi: sortOrder(roi_based_sorting) };
		} else if (date_based_sorting === "desc") {
			sortCondition = { start_date: sortOrder(date_based_sorting) };
		}

		const eventEachPage = 9;

		const events = await Event.find(query)
			.sort(sortCondition)
			.skip((page - 1) * eventEachPage)
			.limit(eventEachPage);

		if (!events) {
			return NextResponse.json(
				{ message: "No events found" },
				{ status: 404 }
			);
		}

		for (let i = 0; i < events.length; i++) {
			const transactions = await Transaction.find({
				event: events[i]._id,
			});

			const totalInvested = transactions.reduce((acc, curr) => {
				return acc + curr.amount;
			}, 0);

			const remaining = events[i].maximum_deposit - totalInvested;

			events[i] = {
				...events[i]._doc,
				remaining,
			};
		}

		const totalPages = Math.ceil(
			(await Event.countDocuments(query)) / eventEachPage
		);

		return NextResponse.json({ events, totalPages }, { status: 200 });
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};
