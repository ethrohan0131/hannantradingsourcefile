import { NextResponse } from "next/server";
import puppeteer from "puppeteer-core";

export const POST = async (req: Request) => {
	const { investors } = await req.json();

	if (!investors) {
		return NextResponse.json(
			{ error: "Investor data is required" },
			{ status: 400 }
		);
	}

	const htmlContent = `
    <html>
      <head>
        <style>
          h1 {
            text-align: center;
            font-size: 14px;
          }
          table {
            width: 100%;
            border: 1px solid black;
            border-collapse: collapse;
            margin-top: 20px;
          }
          th, td {
            padding: 4px;
            text-align: center;
            border: 1px solid black;
          }
          th {
            font-size: 12px;
            font-weight: normal;
          }
          tr:nth-child(even) {
            background-color: #f2f2f2;
          }
        </style>
      </head>
      <body>
        <div>
          <h1>ফেইসবুক/ইউটিউব/ট্রেডিং সাইটে ইনভেস্টর গ্রাহকের নামের তালিকা ও টাকার পরিমাণ।</h1>
          <h1>পরিচালনায়ঃ মোঃ আবদুল হান্নান মিয়াজি, সহপাঠীঃ নুর খান (সিহাব)</h1>
          <table>
            <thead>
              <tr>
                <th>ক্রমিক নং</th>
                <th>নাম</th>
                <th>জাতীয় পরিচয় পত্র</th>
                <th>নমিনির নাম</th>
                <th>নমিনির জাতীয় পরিচয় পত্র</th>
                <th>পেমেন্ট মেথড</th>
                <th>পরিমান</th>
                <th>শতকরা</th>
                <th>ফোন</th>
              </tr>
            </thead>
            <tbody>
              ${investors
					.map((investor: any, index: number) => {
						return `
                  <tr>
                      <td>${index + 1}</td>
                      <td>${investor.name}</td>
                      <td>${investor.nid}</td>
                      <td>${investor.nominee_name}</td>
                      <td>${investor.nominee_nid}</td>
                      <td>${investor.payment_method}</td>
                      <td>${investor.amount}</td>
                      <td>${investor.percentage}</td>
                      <td>${investor.phone}</td>
                  </tr>
                `;
					})
					.join("")}
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `;

	try {
		const browser = await puppeteer.launch({
			executablePath: "/usr/bin/chromium-browser",
			headless: true,
			args: ["--no-sandbox", "--disable-setuid-sandbox"],
		});

		const page = await browser.newPage();
		await page.setContent(htmlContent, { waitUntil: "load" });

		const pdfBuffer = await page.pdf({
			format: "A4",
			landscape: false,
			printBackground: true,
			margin: {
				top: "20px",
				right: "20px",
				bottom: "20px",
				left: "20px",
			},
		});

		await browser.close();

		return new NextResponse(pdfBuffer, {
			headers: {
				"Content-Type": "application/pdf",
				"Content-Disposition":
					'attachment; filename="investor_list.pdf"',
			},
		});
	} catch (error) {
		return NextResponse.json(
			{ error: "Failed to generate PDF File" },
			{ status: 500 }
		);
	}
};
