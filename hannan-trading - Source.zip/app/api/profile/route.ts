import { NextResponse } from "next/server";
import { connectToDB } from "@/lib/mongoDB";
import User from "@/models/User";
import { currentUser } from "@clerk/nextjs/server";

interface TempUser {
	fullname: string;
	profile_picture: string;
	role: string;
	_id: string;
}

export const GET = async (req: Request) => {
	try {
		await connectToDB();
		const { searchParams } = new URL(req.url);
		const email = searchParams.get("email");

		if (!email) {
			return NextResponse.json(
				{ message: "Email is required" },
				{ status: 400 }
			);
		}

		const user = await User.findOne({ email }).select("-password");

		if (!user) {
			return NextResponse.json(
				{ message: "User not found" },
				{ status: 404 }
			);
		}
		return NextResponse.json(user, { status: 200 });
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};

export const POST = async (req: Request) => {
	try {
		await connectToDB();
		const user = await currentUser();

		if (!user) {
			return NextResponse.json(
				{ message: "Unauthorized" },
				{ status: 401 }
			);
		}

		const dbUser = await User.find({ clerkId: user.id });

		if (!dbUser) {
			return NextResponse.json(
				{ message: "User not found" },
				{ status: 404 }
			);
		}

		const { newUser } = await req.json();

		if (!newUser) {
			return NextResponse.json(
				{ message: "User data is required" },
				{ status: 400 }
			);
		}

		if (
			!newUser.fullname ||
			!newUser.fathername ||
			!newUser.mothername ||
			!newUser.phone ||
			!newUser.district ||
			!newUser.house_no ||
			!newUser.village ||
			!newUser.po ||
			!newUser.ps ||
			!newUser.nid_number ||
			!newUser.profile_picture ||
			!newUser.signature
		) {
			return NextResponse.json(
				{ message: "Please fill all required fields" },
				{ status: 400 }
			);
		}

		const role: string[] = user.publicMetadata.role as string[];

		if (!role.includes("admin")) {
			newUser.admin_verified = false;
		}

		const updatedUser = await User.findOneAndUpdate(
			{ clerkId: user.id },
			newUser,
			{ new: true }
		);

		return NextResponse.json(
			{
				message: "User updated successfully",
				updatedUser,
			},
			{ status: 200 }
		);
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};
