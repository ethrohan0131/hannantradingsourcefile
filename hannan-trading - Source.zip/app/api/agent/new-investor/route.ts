import { NextResponse } from "next/server";
import { connectToDB } from "@/lib/mongoDB";
import { currentUser } from "@clerk/nextjs/server";
import User from "@/models/User";
import Event from "@/models/Event";
import Investor from "@/models/Investor";

export const POST = async (req: Request) => {
	try {
		await connectToDB();

		const user = await currentUser();

		if (!user) {
			return NextResponse.json({ message: "অননুমোদিত" }, { status: 401 });
		}

		const role: string[] = user.publicMetadata.role as string[];

		if (!role.includes("user")) {
			return NextResponse.json({ message: "অননুমোদিত" }, { status: 401 });
		}

		const newUser = await User.findOne({ clerkId: user.id });
		if (!newUser) {
			return NextResponse.json(
				{ message: "ব্যবহারকারী পাওয়া যায়নি" },
				{ status: 404 }
			);
		}

		const { investorSingle } = await req.json();

		if (!investorSingle) {
			return NextResponse.json(
				{ message: "কো-ইনভেস্টর প্রদান করা হয়নি" },
				{ status: 400 }
			);
		}

		if (
			!investorSingle.name ||
			!investorSingle.nid ||
			!investorSingle.nominee_name ||
			!investorSingle.nominee_nid ||
			!investorSingle.payment_method ||
			!investorSingle.date ||
			!investorSingle.amount ||
			!investorSingle.percentage ||
			!investorSingle.phone
		) {
			return NextResponse.json(
				{ message: "কো-ইনভেস্টর তথ্য প্রদান করা হয়নি" },
				{ status: 400 }
			);
		}

		const newInvestor = new Investor({
			...investorSingle,
			user: newUser._id,
		});

		await newInvestor.save();

		return NextResponse.json({ message: "সফল" }, { status: 200 });
	} catch (err) {
		return NextResponse.json(
			{ message: "অভ্যন্তরীণ সার্ভার ত্রুটি" },
			{ status: 500 }
		);
	}
};
