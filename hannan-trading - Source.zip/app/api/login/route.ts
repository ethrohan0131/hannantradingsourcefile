import { NextResponse } from "next/server";
import { connectToDB } from "@/lib/mongoDB";
import User from "@/models/User";

export const POST = async (req: Request) => {
	try {
		await connectToDB();
		const { email, role } = await req.json();
		if (!email) {
			return NextResponse.json(
				{ message: "Invalid email" },
				{ status: 400 }
			);
		}
		const user = await User.findOne({ email });
		if (!user) {
			return NextResponse.json(
				{ message: "User not found" },
				{ status: 404 }
			);
		}
		if (!user.role.includes(role)) {
			return NextResponse.json(
				{ message: "আপনি এডমিন হিসেবে লগইন করতে পারবেন না" },
				{ status: 400 }
			);
		}

		return NextResponse.json(
			{ message: "Logged in successfully" },
			{ status: 200 }
		);
	} catch (err) {
		return NextResponse.json(
			{ message: "Internal server error" },
			{ status: 500 }
		);
	}
};
