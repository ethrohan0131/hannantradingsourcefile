"use client";
import { TextGenerateEffect } from "@/components/ui/text-generate-effect";
import { useInView } from "react-intersection-observer";

export default function Master() {
	const { ref, inView } = useInView({
		triggerOnce: true,
		threshold: 0.1,
	});

	return (
		<div className="flex flex-col gap-[64px] py-[96px]">
			{inView && (
				<div className="flex flex-col gap-[12px] mb-[40px]">
					<div className="flex flex-col gap-[12px]">
						<div className="font-semibold text-[#6941C6] leading-[24px]">
							প্রতিষ্ঠাতা
						</div>
						<div className="font-semibold text-[36px] leading-[44px]">
							<TextGenerateEffect words="মাস্টার মাইন্ডের সাথে পরিচিত হন!" />
						</div>
					</div>
					<div className="text-[20px] text-[#535862] leading-[30px]">
						<TextGenerateEffect words="আমি সম্ভাবনায় ভরপুর একজন ব্যক্তি, আপনার জন্য ১০০% বিশ্বাস নিয়ে!" />
					</div>
				</div>
			)}

			<div ref={ref} hidden={inView}></div>
			<div className="flex flex-col lg:flex-row justify-between items-end w-full gap-[64px]">
				<div className="flex flex-col justify-center w-full">
					<div className="flex flex-col gap-[32px]">
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									মোঃ আব্দুল হান্নান মিয়াজী
								</div>
								<div className="flex w-fit  gap-2 py-[2px] px-[10px] bg-[#EFF8FF] rounded-full text-[#175CD3] items-center border border-[#2E90FA]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#2E90FA] rounded-full"></div>
									<div className="text[14px] font-[500]">
										নাম
									</div>
								</div>
							</div>
							<div className="text-[16px] text-[#535862] leading-[30px]">
								আমি মোঃ আব্দুল হান্নান মিয়াজী, প্রতিষ্ঠাতা,
								জন্ম তারিখ ০৭-০৯-২০০০
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									মৃত আবু সালেক
								</div>
								<div className="flex w-fit  gap-2 py-[2px] px-[10px] bg-[#FDF2FA] rounded-full text-[#C11574] items-center border border-[#FCCEEE]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#EE46BC] rounded-full"></div>
									<div className="text[14px] font-[500]">
										বাবা
									</div>
								</div>
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									মোছাঃ তাসরিন বেগম
								</div>
								<div className="flex w-fit  gap-2 py-[2px] px-[10px] bg-[#FDF2FA] rounded-full text-[#B93815] items-center border border-[#F9DBAF]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#EF6820] rounded-full"></div>
									<div className="text[14px] font-[500]">
										মা
									</div>
								</div>
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="flex flex-col gap-2">
									<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
										বাড়ি- শমদ আলী মাঝি বাড়ি, গ্রাম-
										কেদারখিল,
									</div>
									<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
										পোস্ট অফিস- জাফর নগর, থানা- সীতাকুণ্ড,
										জেলা- চট্টগ্রাম
									</div>
								</div>
								<div className="flex w-fit  gap-2 h-fit py-[2px] px-[10px] bg-[#EEF4FF] rounded-full text-[#3538CD] items-center border border-[#C7D7FE]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#6172F3] rounded-full"></div>
									<div className="text[14px] font-[500]">
										ঠিকানা
									</div>
								</div>
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									১০৩*******
								</div>
								<div className="flex w-fit  gap-2 py-[2px] px-[10px] bg-[#ECFDF3] rounded-full text-[#067647] items-center border border-[#ABEFC6]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#17B26A] rounded-full"></div>
									<div className="text[14px] font-[500]">
										এনাইডি
									</div>
								</div>
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									@hannantrading.org
								</div>
								<div className="flex w-fit  gap-2 py-[2px] px-[10px] bg-[#EEF4FF] rounded-full text-[#004EEB] items-center border border-[#C7D7FE]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#6172F3] rounded-full"></div>
									<div className="text[14px] font-[500]">
										ইমেইল
									</div>
								</div>
							</div>
						</div>
						<div className="flex flex-col">
							<hr className="mb-[32px]" />
							<div className="flex flex-col md:flex-row gap-2">
								<div className="font-semibold text-[20px] text-[#181D27] leading-[24px]">
									+৮৮০-**********
								</div>
								<div className="flex w-fit gap-2 py-[2px] px-[10px] bg-[#FDF4FF] rounded-full text-[#9F1AB1] items-center border border-[#F6D0FE]">
									<div className="min-h-[8px] max-h-[8px] min-w-[8px] max-w-[8px] bg-[#D444F1] rounded-full"></div>
									<div className="text[14px] font-[500]">
										ফোন
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="max-w-[560px] max-h-[640px]">
					<img
						src="/assets/images/root/master.jpeg"
						alt="Get Started"
						width={560}
						height={640}
						className="md:max-w-[560px] md:max-h-[640px] object-cover"
					/>
				</div>
			</div>
		</div>
	);
}
