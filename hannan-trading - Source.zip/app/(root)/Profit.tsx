"use client";
import { TextGenerateEffect } from "@/components/ui/text-generate-effect";
import Image from "next/image";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";

export default function Profit() {
	const { ref, inView } = useInView({
		triggerOnce: true,
		threshold: 0.1,
	});
	return (
		<div className="flex flex-col gap-[64px] py-[96px]">
			<div ref={ref} hidden={inView}></div>
			{inView && (
				<div className="flex flex-col gap-[12px]">
					<div className="flex flex-col gap-[12px]">
						<div className="font-semibold text-[#6941C6] leading-[24px]">
							আমাদের প্রক্রিয়া
						</div>
						<div className="font-semibold text-[36px] leading-[44px]">
							<TextGenerateEffect words="স্মরণীয় মুনাফা তৈরি করুন" />
						</div>
					</div>
					<div className="text-[20px] text-[#535862] leading-[30px]">
						<TextGenerateEffect words="আমরা এমন মুহূর্ত তৈরি করি যা আনন্দ নিয়ে আসে এবং পৃথিবীজুড়ে সুখকে উদ্দীপিত করে।" />
					</div>
				</div>
			)}

			<div className="flex flex-col md:flex-row md:justify-between items-center w-full gap-y-4 md:gap-y-0">
				{inView && (
					<div className="flex flex-col gap-[64px]">
						<div className="flex flex-col md:flex-row justify-center w-full gap-[32px]">
							<div className="flex flex-col items-center">
								<div className="font-semibold text-[60px] text-[#7F56D9]">
									<CountUp duration={4} end={400} />+
								</div>
								<div className="font-semibold text-[18px] text-[#181D27]">
									সম্পন্ন বিনিয়োগ
								</div>
								<div className=" text-[16px] max-w-[264px] text-center text-[#535862]">
									আমরা দেশব্যাপী ৪০০টিরও বেশি অসাধারণ প্রকল্পে
									বিনিয়োগ করেছি।
								</div>
							</div>
							<div className="flex flex-col items-center">
								<div className="font-semibold text-[60px] text-[#7F56D9]">
									<CountUp duration={4} end={600} />%
								</div>
								<div className="font-semibold text-[18px] text-[#181D27]">
									বিনিয়োগের উপর লাভ
								</div>
								<div className=" text-[16px] max-w-[264px] text-center text-[#535862]">
									আমাদের গ্রাহকরা গড়ে ~৬০০% ROI রিপোর্ট
									করেছেন।
								</div>
							</div>
						</div>
						<div className="flex flex-col md:flex-row justify-center w-full gap-[32px]">
							<div className="flex flex-col items-center">
								<div className="font-semibold text-[60px] text-[#7F56D9]">
									<CountUp duration={4} end={50} />+
								</div>
								<div className="font-semibold text-[18px] text-[#181D27]">
									বিশ্বব্যাপী সদস্যগণ
								</div>
								<div className=" text-[16px] max-w-[264px] text-center text-[#535862]">
									আমাদের ফ্রি UI কিটটি ১০,০০০ এরও বেশি বার
									ডাউনলোড করা হয়েছে।
								</div>
							</div>
							<div className="flex flex-col items-center">
								<div className="font-semibold text-[60px] text-[#7F56D9]">
									<CountUp duration={4} end={48} />+
								</div>
								<div className="font-semibold text-[18px] text-[#181D27]">
									৫-তারকা রিভিউসমূহ
								</div>
								<div className=" text-[16px] max-w-[264px] text-center text-[#535862]">
									আমরা আমাদের ৫-তারকা রেটিং নিয়ে গর্বিত, যা
									৪৮টিরও বেশি রিভিউর মাধ্যমে প্রমাণিত।
								</div>
							</div>
						</div>
					</div>
				)}

				<div className="max-w-[560px] max-h-[640px]">
					<Image
						src="/assets/images/root/profit.png"
						alt="Get Started"
						width={560}
						height={640}
						className="md:max-w-[560px] md:max-h-[640px] object-cover"
					/>
				</div>
			</div>
		</div>
	);
}
