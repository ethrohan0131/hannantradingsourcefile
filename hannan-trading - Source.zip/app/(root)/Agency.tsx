import Image from "next/image";
import Link from "next/link";

export default function GetStarted() {
	return (
		<div className="flex flex-col md:flex-row justify-between items-center w-full py-[96px] gap-[64px]">
			<div className="flex flex-col justify-center">
				<div className="font-semibold text-[#6941C6] leading-[24px]">
					হান্নান ট্রেডিং
				</div>
				<div className="flex flex-col gap-[48px]">
					<div className="text-[#181D27] font-semibold text-[36px]">
						আপনার বিশ্বব্যাপী বাণিজ্য ও বাণিজ্যে বিশ্বস্ত অংশীদার।
					</div>

					<div className="text-[#535862] text-[18px]">
						হান্নান ট্রেডিং-এ, আমরা উচ্চমানের পণ্য এবং পরিষেবা
						সরবরাহে বিশেষজ্ঞ যা বিশ্বের ব্যবসায়িক প্রয়োজনের সাথে
						সঙ্গতিপূর্ণ। আমাদের বিভিন্ন ধরনের পণ্য বিভিন্ন শিল্পের
						জন্য উপযোগী, যা নিশ্চিত করে যে আমরা আমাদের ক্লায়েন্টদের
						জন্য সর্বোত্তম সরবরাহ করি।
						<br />
						<br />
						আমরা গ্রাহক সন্তুষ্টিকে অগ্রাধিকার দিই এবং আপনার সকল
						বাণিজ্যিক প্রয়োজনের জন্য সময়মতো, নির্ভরযোগ্য সমাধান
						সরবরাহ করি। বছরের অভিজ্ঞতা এবং একটি নিবেদিত দলের সাথে,
						হান্নান ট্রেডিং বিশ্ব বাজারে নেতৃত্ব দিতে থাকে, উদ্ভাবনী
						পণ্য এবং চমৎকার পরিষেবা প্রদান করে।
						<br />
						<br />
						আপনি যদি শীর্ষ মানের পণ্য, দক্ষ লজিস্টিক্স বা বিশেষভাবে
						তৈরি ব্যবসায়িক সমাধান খুঁজছেন, হান্নান ট্রেডিং আপনার
						ব্যবসায়িক উন্নতির জন্য এখানে আছেন।
						<br />
						<br />
						গুণমান, স্বচ্ছতা এবং গ্রাহক সেবায় আমাদের প্রতিশ্রুতি
						আমাদেরকে নির্ভরযোগ্য বাণিজ্যিক অংশীদার খুঁজছেন এমন
						ব্যবসায়ের জন্য আদর্শ পছন্দ করে তোলে।
					</div>
					<div className="flex flex-col md:flex-row gap-[12px]">
						<Link
							href="/contact"
							className="bg-white hover:bg-gray-100 px-[18px] py-[12px] rounded-[8px] teaxt-[16px] font-semibold text-[#414651] border border-[#D5D7DA]"
						>
							যোগাযোগ করুন
						</Link>
						<Link
							href="/our-process"
							className="bg-[#7F56D9] hover:bg-[#734dc4] px-[18px] py-[12px] rounded-[8px] teaxt-[16px] font-semibold text-[#FFFFFF]"
						>
							আমাদের প্রক্রিয়া
						</Link>
					</div>
				</div>
			</div>

			<div className="max-w-[560px] max-h-[640px]">
				<Image
					src="/assets/images/root/agency.png"
					alt="Get Started"
					width={560}
					height={640}
					className="md:max-w-[560px] md:max-h-[640px] object-cover"
				/>
			</div>
		</div>
	);
}
