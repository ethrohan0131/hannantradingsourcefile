"use client";
import { useState, useRef } from "react";
import Image from "next/image";
import User from "@/interfaces/User";
import toast from "react-hot-toast";
import { useSignUp } from "@clerk/nextjs";

export default function StepFive({ user }: { user: User | null }) {
	const [loading, setLoading] = useState(false);
	const { isLoaded, signUp } = useSignUp();
	const [otp, setOtp] = useState(Array(6).fill(""));
	const inputRefs = useRef<HTMLInputElement[]>([]);

	const handleChange = (value: string, index: number) => {
		if (!/^\d$/.test(value) && value !== "") return;
		const updatedOtp = [...otp];
		updatedOtp[index] = value;
		setOtp(updatedOtp);

		if (value !== "" && index < 5) {
			inputRefs.current[index + 1]?.focus();
		}
	};

	const handleBackspace = (index: number) => {
		const updatedOtp = [...otp];
		updatedOtp[index] = "";
		setOtp(updatedOtp);

		if (index > 0) {
			inputRefs.current[index - 1]?.focus();
		}
	};

	const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
		e.preventDefault();
		const pasteData = e.clipboardData.getData("text").slice(0, 6);
		const updatedOtp = otp.map((_, idx) => pasteData[idx] || "");
		setOtp(updatedOtp);

		const nextIndex = pasteData.length - 1;
		if (nextIndex >= 0 && nextIndex < 6) {
			inputRefs.current[nextIndex]?.focus();
		}
	};

	async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
		e.preventDefault();
		if (!isLoaded) return;
		if (!user) return;
		setLoading(true);
		const tempUser: User | null = { ...user };

		const otpCode = otp.join("");
		if (otpCode.length < 6) {
			toast.error("Please enter the complete OTP");
			setLoading(false);
			return;
		}

		const responseOld = await fetch("/api/email-verification", {
			method: "PUT",
			body: JSON.stringify({ email: user.email, otp: otpCode }),
		});

		const dataOld = await responseOld.json();

		if (responseOld.status !== 200) {
			toast.error(dataOld.message);
			setLoading(false);
			return;
		}

		let clerkId = null;
		try {
			const res = await signUp.create({
				emailAddress: tempUser.email,
				password: tempUser.password,
			});
			clerkId = res.createdUserId;
		} catch (error) {
			toast.error("Failed to create user");
			setLoading(false);
			return;
		}

		if (!clerkId) {
			toast.error("Failed to create user");
			setLoading(false);
			return;
		}

		tempUser.clerkId = clerkId;
		const response = await fetch("/api/signup", {
			method: "POST",
			body: JSON.stringify({ tempUser }),
		});
		const data = await response.json();
		if (response.status === 201) {
			toast.success(data.message);
			window.location.reload();
		} else {
			toast.error(data.message);
		}
		setLoading(false);
	}

	return (
		<div className="w-full max-w-md mx-auto flex flex-col justify-center gap-y-[2rem] pt-16">
			<div className="flex flex-col items-center gap-y-[2rem]">
				<div className="bg-white border p-[14px] rounded-[12px] ">
					<Image
						src="/assets/Icons/phone-01.svg"
						width={28}
						height={28}
						alt="phone"
					/>
				</div>
				<div className="flex flex-col gap-y-[0.75rem]">
					<h2 className="text-[1.875rem] text-[#181D27] font-semibold text-center leading-tight">
						আপনার ইমেইল চেক করুন
					</h2>
					<h2 className="text-center text-[#535862]">
						আমরা একটি ভেরিফিকেশন কোড প্রেরণ করেছি আপনার ইমেইলে।
					</h2>
					<h2 className="text-center text-[#535862]">
						{user?.email}
					</h2>
				</div>
			</div>

			<form className="space-y-4" onSubmit={handleSubmit}>
				<div className="flex gap-2 justify-center">
					{otp.map((digit, index) => (
						<input
							key={index}
							type="text"
							title="otp"
							value={digit}
							onChange={(e) =>
								handleChange(e.target.value, index)
							}
							onKeyDown={(e) => {
								if (e.key === "Backspace") {
									handleBackspace(index);
								}
							}}
							onPaste={handlePaste}
							ref={(el) => {
								inputRefs.current[index] = el!;
							}}
							maxLength={1}
							autoFocus={index === 0}
							className="lg:w-[80px] w-[40px] lg:h-[80px] h-[40px] text-center border border-purple-400 rounded-md text-3xl font-semibold focus:outline-none focus:ring-2 focus:ring-purple-600"
						/>
					))}
				</div>

				<button
					type="submit"
					className="w-full p-[10px] font-semibold bg-[#7a53cf] text-white rounded-md hover:bg-[#6947b1] disabled:bg-gray-400"
					disabled={loading}
				>
					{loading ? "প্রসেস হচ্ছে..." : "ভেরিফাই করুন"}
				</button>
			</form>
			<div className="flex gap-[1rem] w-full justify-center mt-8">
				<div className="min-h-[0.625rem] max-h-[0.625rem] min-w-[0.625rem] max-w-[0.625rem] bg-[#E9EAEB] rounded-full"></div>
				<div className="min-h-[0.625rem] max-h-[0.625rem] min-w-[0.625rem] max-w-[0.625rem] bg-[#E9EAEB] rounded-full"></div>
				<div className="min-h-[0.625rem] max-h-[0.625rem] min-w-[0.625rem] max-w-[0.625rem] bg-[#E9EAEB] rounded-full"></div>
				<div className="min-h-[0.625rem] max-h-[0.625rem] min-w-[0.625rem] max-w-[0.625rem] bg-[#E9EAEB] rounded-full"></div>
				<div className="min-h-[0.625rem] max-h-[0.625rem] min-w-[0.625rem] max-w-[0.625rem] bg-[#7F56D9] rounded-full"></div>
			</div>
		</div>
	);
}
