"use client";
import Marquee from "react-fast-marquee";

interface RatingProps {
	quote: string;
	name: string;
	title: string;
}

const rating_list: RatingProps[] = [
	{
		quote: "আমাদের নতুন অফিস স্থাপন প্রক্রিয়ায় প্রতিটি পদক্ষেপে সহায়তা করেছে।",
		name: "সিয়েনা হিউইট",
		title: "প্রজেক্ট ম্যানেজার, ওয়ার্পস্পিড",
	},
	{
		quote: "টিমটি প্রক্রিয়া পরিষ্কারভাবে ব্যাখ্যা করেছে এবং আমাদের শুরু করতে সাহায্য করেছে।",
		name: "কিয়ান ডাফি",
		title: "সিইও, ওয়ার্পস্পিড",
	},
	{
		quote: "আমরা ফলাফল নিয়ে খুব খুশি এবং অন্যদের জন্য তাদের সুপারিশ করব।",
		name: "জাসমিন মাক্কয়",
		title: "প্রজেক্ট ম্যানেজার, ওয়ার্পস্পিড",
	},
];

export default function CardMarquee() {
	return (
		<Marquee loop={0} autoFill={false} className="h-full">
			<div className="h-full flex justify-center items-center">
				{rating_list.map((rating, index) => (
					<div
						key={index}
						className="mx-4 bg-slate-800 flex flex-col h-full justify-between max-w-64 p-4 rounded-lg antialiased"
					>
						<p className="text-white text-lg mb-12 font-semibold">
							{rating.quote}
						</p>
						<div>
							<p className="text-gray-300 font-sm">
								{rating.name}
							</p>
							<p className="text-gray-300 font-sm">
								{rating.title}
							</p>
						</div>
					</div>
				))}
			</div>
		</Marquee>
	);
}
