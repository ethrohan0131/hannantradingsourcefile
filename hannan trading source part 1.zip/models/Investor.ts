import mongoose from "mongoose";

const InvestorSchema = new mongoose.Schema({
	user: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "User",
		required: true,
	},
	name: {
		type: String,
		required: false,
	},
	nid: {
		type: String,
		required: true,
	},
	nominee_name: {
		type: String,
		required: true,
	},
	nominee_nid: {
		type: String,
		required: true,
	},
	payment_method: {
		type: String,
		required: true,
	},
	date: {
		type: Date,
		required: true,
	},
	amount: {
		type: Number,
		required: true,
	},
	percentage: {
		type: Number,
		required: true,
	},
	phone: {
		type: String,
		required: true,
	},
});

const Investor =
	mongoose.models.Investor || mongoose.model("Investor", InvestorSchema);

export default Investor;
